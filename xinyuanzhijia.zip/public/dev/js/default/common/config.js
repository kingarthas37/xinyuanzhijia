'use strict';

window.leanApp = {
    AppID:'QuiPuWpJPzCahsgBK7teBOJN-gzGzoHsz',
    AppKey:'Wwh9RRHIySPlvToe3dsIVfS7',
    MasterKey:'mCIsLsrtOgujruzfcEGDm9Uh',
    api:'https://api.leancloud.cn/1.1/'
};

window.taobaoShop = {
    shop1Name:'暮雪的心愿城',
    shop2Name:'亚特兰蒂斯之谜',
    shop1:'//muxue698.taobao.com',
    shop2:'//muxue928.taobao.com'
};