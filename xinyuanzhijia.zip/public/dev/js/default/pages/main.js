require('../../../../js/main');

require('./home');
require('./order');
require('./index');
require('./user');
require('./product-list');
require('./product-detail');
require('./cart');
require('./article');