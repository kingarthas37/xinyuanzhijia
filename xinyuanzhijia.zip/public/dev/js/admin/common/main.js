require('../../../../js/main');

require('./config');
require('./common');